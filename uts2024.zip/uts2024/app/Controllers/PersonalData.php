<?php

namespace App\Controllers;

use App\Models\PersonalDataModel;

class PersonalData extends BaseController
{
    public function index()
    {
        $model = new PersonalDataModel();
        $data['personal_data'] = $model->findAll(); // Ambil semua data dari tabel personal_data
        return view('personal_data/index', $data);
    }
}
