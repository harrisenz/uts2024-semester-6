<?php

namespace App\Models;

use CodeIgniter\Model;

class PersonalDataModel extends Model
{
    protected $table = 'personal_data';
    protected $primaryKey = 'id';
    protected $allowedFields = ['full_name', 'email', 'phone', 'address', 'about_me', 'education', 'skills', 'experience'];
}
