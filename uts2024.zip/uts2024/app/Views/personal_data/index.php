<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTS</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <link href="<?= base_url('css/styles.css') ?>" rel="stylesheet">

</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark animate__animated animate__fadeInDown">
        <div class="container">
            <a class="navbar-brand" href="#">UTS</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Profil</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-5">
        <h1 class="text-center hero-title animate__animated animate__fadeInDown hero-title-animation">CV</h1>
        <div class="row justify-content-center">
            <!-- Personal Data -->
            <div class="col-lg-6 mb-4">
                <?php foreach ($personal_data as $data) : ?>
                    <div class="card animate__animated animate__fadeInUp">
                        <div class="card-header text-center">
                            <img src="<?= base_url('assets/images/1.jpeg') ?>" alt="Profile Photo" class="img-fluid rounded-circle" style="max-width: 150px;">
                            <h2 class="card-title mt-3"><?= $data['full_name'] ?></h2>
                        </div>
                        <!-- Personal Data -->
                        <div style="text-align:center">
                            <div class="card-body">
                                <div class="personal-info">
                                    <p><strong>Email:</strong> <?= $data['email'] ?></p>
                                </div>
                                <div class="personal-info">
                                    <p><strong>Phone:</strong> <?= $data['phone'] ?></p>
                                </div>
                                <div class="personal-info">
                                    <p><strong>Address:</strong> <?= $data['address'] ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- About Me and Experience Cards -->
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 mb-4">
                <div class="card about-card animate__animated fade-in-bottom">
                    <div class="card-header" style="text-align:center">
                        <h3>education</h3>
                    </div>
                    <div class="card-body" style="text-align: center">
                        <p><?= $data['education'] ?></p>
                    </div>
                </div>
                <div class="card about-card animate__animated fade-in-bottom">
                    <div class="card-header" style="text-align:center">
                        <h3>skills</h3>
                    </div>
                    <div class="card-body" style="text-align: center">
                        <p><?= $data['skills'] ?></p>
                    </div>
                </div>
                <div class="card about-card animate__animated fade-in-bottom">
                    <div class="card-header" style="text-align:center">
                        <h3>About Me</h3>
                    </div>
                    <div class="card-body" style="text-align: justify">
                        <p><?= $data['about_me'] ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-6 mb-4">
                <div class="card experience-card animate__animated fade-in-bottom">
                    <div class="card-header" style="text-align:center">
                        <h3>Experience</h3>
                    </div>
                    <div class="card-body" style="text-align: justify">
                        <p><?= $data['experience'] ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2024. Haris Ristu Sendang.</p>
    </div>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Add fade-in effect to cards
        document.addEventListener('DOMContentLoaded', function() {
            var fadeTargets = document.querySelectorAll('.fade-in-bottom');

            fadeTargets.forEach(function(target) {
                target.classList.add('active');
            });
        });
    </script>
</body>

</html>