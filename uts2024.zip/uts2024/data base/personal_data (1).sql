-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2024 at 11:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cv_portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `personal_data`
--

CREATE TABLE `personal_data` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `about_me` text DEFAULT NULL,
  `education` text DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `experience` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personal_data`
--

INSERT INTO `personal_data` (`id`, `full_name`, `email`, `phone`, `address`, `about_me`, `education`, `skills`, `experience`) VALUES
(1, 'Haris Ristu Sendang', 'harisristusendang@gmail.com', '085798765432', 'sukabumi, indonesia', 'Hai, saya Haris Ristu Sendang, seorang pengembara di dunia digital yang senang menjelajahi segala sesuatu tentang teknologi.\r\n\r\nSaya adalah penggemar berat pengembangan perangkat lunak. Dari aplikasi mobile yang sederhana hingga sistem informasi yang kompleks.\r\n\r\n\r\nDi luar kuliah, saya aktif dalam berbagai organisasi baik itu sosial maupun club olahraga. Saya terlibat dalam kelompok kemanusiaan, pendidikan, dan klub basket. Keterlibatan ini memperluas wawasan saya dan mengajarkan keterampilan sosial. Saya percaya bahwa berbagi pengetahuan dan pengalaman dengan orang lain adalah kunci untuk tumbuh dan berkembang sebagai seorang profesional.\r\n\r\n', 'universitas muhammadiyah sukabumi', 'Pemrograman, Pengembangan Perangkat Lunak, Keterampilan Desain, Analitis, Keterampilan Komunikasi, Kolaborasi Tim, Manajemen Proyek, Keterampilan Pembelajaran Mandiri', 'Di semester keenam saya, sebagai mahasiswa TI, saya menemukan keseimbangan antara kuliah dan eksplorasi pribadi. Saya tidak lagi merasa cemas dengan adaptasi kampus, fokus saya lebih pada pengembangan diri.\r\n\r\nSelain belajar, saya aktif dalam berbagai organisasi baik itu sosial maupun club olahraga. Saya terlibat dalam kelompok kemanusiaan, pendidikan, dan klub basket. Keterlibatan ini memperluas wawasan saya dan mengajarkan keterampilan sosial.\r\n\r\nTentu, ada tantangan juga. saya harus menyeimbangkan kehidupan sosial dengan akademis.\r\n\r\nPengalaman saya di semester keenam adalah perpaduan antara dedikasi akademis dan eksplorasi pribadi, yang membuat saya tumbuh sebagai seorang profesional yang terampil dan berpengetahuan luas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `personal_data`
--
ALTER TABLE `personal_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `personal_data`
--
ALTER TABLE `personal_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
